package Lesson7;

public class Main {

    public static void main(String[] args) {

        Employer teckleader = new Employer();
//        teckleader.printer();
//        System.out.println("/........................................../");

        Employer teamLeader = new Employer("Mane ", "Abgaryan ", "05/07/1988 ", "TeamViewer ", 500000.0);
//        teamLeader.printer();
//        System.out.println("/........................................../");
        Employer seniorAutomation = new Employer("Vanik ", "Margaryan ", "22/06/1995 ", "SFL ", 400000.0);
//        seniorAutomation.printer();
//        System.out.println("/........................................../");
        Employer juniormanual = new Employer("Arman ", "Khandikyan ", "14/09/1998 ", "Renderforest ", 200000.0);
//        juniormanual.printer();
//        System.out.println("/........................................../");


//        String temp = juniormanual.getinfo();

        Employer[] employerZ = new Employer[4];
        employerZ[0] = teckleader;
        employerZ[1] = teamLeader;
        employerZ[2] = seniorAutomation;
        employerZ[3] = juniormanual;
        for (int i = 0; i < employerZ.length; i++) {
            System.out.println(employerZ[i].getinfo());
        }

    }
}
