public class ArrayHomework {

    public static void main(String[] args) {

        int array [] = new int[10];

        for (int i = 0; i <= array.length-1; i++) {

            for (int j = array.length-1; j >= 0; j--)

            System.out.println("Array [" + i + "] " + j);
        }
    }
}
